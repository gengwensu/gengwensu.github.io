# -*- coding: utf-8 -*-

'''*
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*'''

import xbmc
from threading import Thread
from commoncore.kodi import enum, log, kodi_json_request


EVENTS = enum(IDLE=0, STARTED=1, PLAYING=2, STOPPED=3, PAUSED=4, RESUMED=5, SEEKING=6)
WAIT_DELAY = .25

class Monitor(xbmc.Monitor):
	def onSettingsChanged(self):
		pass

class ActivePlayer(xbmc.Player):
	__abort_flag			= False
	__started_flag			= False
	__paused_flag			= False
	__seeking_flag			= False
	__uid					= ''
	__percent				= 0
	__current 				= 0
	__total 				= 0

	def __init__(self):
		xbmc.Player.__init__(self)
	
	def play(self, item="", listitem=None, windowed=False, startpos=-1):
		Thread(target=self.event_monitor).start()
		super(ActivePlayer, self).play(item, listitem, windowed, startpos)
	
	@property
	def __playing(self):
		return len(kodi_json_request("Player.GetActivePlayers", {})['result']) > 0
	
	@property
	def __paused(self):
		try:
			return kodi_json_request("Player.GetProperties", {"playerid": 1, "properties": ["speed"]})['result']['speed'] == 0
		except:
			return False
	
	@property
	def __seeking(self):
		try:
			return kodi_json_request("Player.GetProperties", {"playerid": 1, "properties": ["speed"]})['result']['speed'] > 1
		except:
			return False
	@property
	def uid(self):
		return self.__uid

	@property
	def percent(self):
		return self.__percent

	@property
	def current_time(self):
		return self.__current

	@property
	def total_time(self):
		return self.__total
	
	@property
	def event(self):
		if self.__started_flag is False and self.__playing is True:
			log("Playback Event: ***************** Started")
			self.__started_flag = True
			return EVENTS.STARTED
		elif self.__started_flag is True and self.__playing is False:
			self.__abort_flag = True
			log("Playback Event: ***************** Stopped")
			return EVENTS.STOPPED
		elif self.__paused_flag is False and self.__paused is True:
			log("Playback Event: ***************** Paused")
			self.__paused_flag = True
			return EVENTS.PAUSED
		elif (self.__paused_flag is True or self.__seeking_flag is True) and self.__paused is False and self.__seeking is False:
			log("Playback Event: ***************** Resumed")
			self.__paused_flag = False
			self.__seeking_flag = False
			return EVENTS.RESUMED
		elif self.__seeking is True:
			log("Playback Event: ***************** Seeking")
			self.__seeking_flag = True
			return EVENTS.SEEKING
		elif self.__started_flag is True and self.__playing is True:
			self.get_current_times()
			return EVENTS.PLAYING
		else:
			return EVENTS.IDLE

	def get_current_times(self):
		try:
			r = kodi_json_request("Player.GetProperties", {"playerid": 1, "properties": ["totaltime", "time", "percentage"]})['result']
			self.__current = float(r['time']['hours']) * 3600 + float(r['time']['minutes']) * 60 + float(r['time']['seconds']) + float(r['time']['milliseconds'])/1000
			self.__total = float(r['totaltime']['hours']) * 3600 + float(r['totaltime']['minutes']) * 60 + float(r['totaltime']['seconds']) + float(r['totaltime']['milliseconds'])/1000
			self.__percent = float(r['percentage'])
		except:
			pass

	def event_monitor(self):
		monitor = Monitor()
		event_map = {
			EVENTS.STARTED:			self.onPlayBackStarted,
			EVENTS.STOPPED:			self.onPlayBackStopped,
			EVENTS.PAUSED:			self.onPlayBackPaused,
			EVENTS.RESUMED:			self.onPlayBackResumed,
			EVENTS.SEEKING:			self.onPlayBackSeeking,
			EVENTS.PLAYING: 		self.onPlayBack
		}
		while not monitor.abortRequested() or self.__abort_flag:
			if monitor.waitForAbort(WAIT_DELAY) or self.__abort_flag:
				break
			event = self.event
			if event in event_map:
				if type(event_map[event]) is dict:
					args = event_map[event]['args'] if 'args' in event_map[event] else ()
					kwargs = event_map[event]['kwargs'] if 'kwargs' in event_map[event] else {}
					event_map[event]['target'](*args, **kwargs)
				else:
					event_map[event]()
	
	def onPlayBack(self):
		pass
	
	def onPlayBackStarted(self):
		pass
	
	def onPlayBackSeeking(self):
		pass
	
	def onPlayBackPaused(self):
		pass

	def onPlayBackResumed(self):
		pass
	
	def onPlayBackStopped(self):
		pass
