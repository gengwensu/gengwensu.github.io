# -*- coding: utf-8 -*-

'''*
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*'''
from . import strings
from .enum import enum
from .addon import get_name, get_version, get_setting
from xbmc import log as __log
from xbmc import LOGDEBUG, LOGINFO, LOGWARNING, LOGFATAL
LEVELS = enum(NONE=100, INFO=4, WARN=3, DEBUG=2, VERBOSE=1)
table = {"verbose": LEVELS.VERBOSE, "info": LEVELS.INFO, "debug": LEVELS.DEBUG, "warn": LEVELS.WARN}
LOG_LEVEL = table[get_setting("log_level", "script.module.commoncore")]
LOG_FORMAT = "{NAME} v{VERSION}: {MESSAGE}"

def log(msg, LEVEL=LEVELS.INFO):
    if (LEVEL >= LOG_LEVEL):
        msg = LOG_FORMAT.format(NAME=get_name(), VERSION=get_version(), MESSAGE=msg)
        __log(msg, LOGINFO)

def info(msg):
    log(msg, LEVELS.INFO)
    
def warn(msg):
    log(msg, LEVELS.WARN)
    
def debug(msg):
    log(msg, LEVELS.DEBUG)

def verbose(msg):
    log(msg, LEVELS.VERBOSE)
