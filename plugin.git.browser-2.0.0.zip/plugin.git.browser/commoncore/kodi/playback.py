# -*- coding: utf-8 -*-

'''*
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*'''

import json
import xbmc
import xbmcplugin
import xbmcgui
from .constants import *
from .runner import args
from .addon import get_property, set_property, clear_property, go_to_url, get_window, refresh
from .ui import notify, dialog_context
from commoncore.kodi import log, get_setting, format_time
from commoncore.player import ActivePlayer
	
def set_trakt_ids(ids):
	trakt_ids = {}
	def update_key(k, v):
		if v is not None and v:
			trakt_ids[k]=v	
	if "episode_ids" in ids: ids = ids["episode_ids"]
	for k in ['tmdb', 'tvdb', 'imdb', 'trakt', 'slug']:
		if k in ids:
			update_key(k, ids[k])
		elif k + '_id' in ids:
			update_key(k, ids[k+'_id'])
	log("Set Trakt IDs: %s" % trakt_ids)
	xbmcgui.Window(10000).setProperty('script.trakt.ids', json.dumps(trakt_ids))

on_playback_started = None
		
on_playback_paused = None
		
on_playback_resumed = None

on_playback_stopped = None

def unset_trakt_ids():
	get_window().clearProperty('script.trakt.ids')

def format_info(info):
	allowed = ["title", "season", "episode", "tvshowtitle", "imdbnumber", "year", "duration"] #, "totaltime", "startpercent", "resumetime"]
	formated = {k:v for k,v in list(info.items()) if k.lower() in allowed}
	return formated

def play_stream(url, info):
	title = info["title"] if "title" in info else ""
	poster = info.pop("poster") if "poster" in info else ""
	poster = info.pop("cover_url") if "cover_url" in info else poster
	listitem = xbmcgui.ListItem(title, path=url)
	listitem.setPath(url)
	listitem.setArt({"thumb": poster})
	listitem.setInfo("video", format_info(info))
	listitem.setProperty('IsPlayable', 'true')
	'''if xbmc.getInfoLabel('ListItem.PercentPlayed') == '0':
		if get_setting('use_trakt_progress') == 'true':
			from commoncore import trakt
			percent_str = trakt.get_playback_episode(info['ids']['trakt'])
			percent = float(percent_str) / 100
			if percent:
				total = info['duration'] * 60
				seconds = total * percent
				if seconds > 60 and dialog_context(["Resume from %s" % format_time(seconds, True), 'Play from beginning']) == 0:
					listitem.setProperty('StartPercent', str(percent_str))
					listitem.setProperty('TotalTime', str(total))
		elif 'StartPercent' in info and 'TotalTime' in info:
				seconds = float(info['ResumeTime'])
				if seconds > 60 and dialog_context(["Resume from %s" % format_time(seconds, True), 'Play from beginning']) == 0:
					listitem.setProperty('StartPercent', str(info['StartPercent']))
					listitem.setProperty('TotalTime', str(info['TotalTime']))	'''
			
	class Player(ActivePlayer):
		def __init__(self):
			ActivePlayer.__init__(self)
			self.video_ids = json.loads(xbmcgui.Window(10000).getProperty('script.trakt.ids'))
			if 'episode' in info and info['episode']:
				self.media = 'show'
			else:
				self.media = 'movie'
				
		def onPlayBackStarted(self):
			log("I'm called")
			if on_playback_started is not None: on_playback_started()
		
		def onPlaybackPaused(self):
			#self.set_playback()
			#on_playback_paused()
			if on_playback_paused is not None: on_playback_paused()
			
		def onPlaybackResumed(self):
			if on_playback_resumed is not None: on_playback_resumed()

		def onPlayBackStopped(self):
			if on_playback_stopped is not None: on_playback_stopped()
			#self.set_playback()
			#if get_setting("refresh_onstop") == "true": refresh()
			
		def set_playback(self):
			watched = 1 if self.percent >= 95 else 0
			from infohandler import infolabels
			season = info['season'] if 'season' in info and info['season'] else ''
			episode = info['episode'] if 'episode' in info and info['episode'] else ''
			infolabels.set_playback(self.current_time, self.total_time, self.percent, self.media, info['ids']['trakt'], season, episode)
	if HANDLE_ID > 0:
		log("Handle ID %s " % HANDLE_ID)		
		xbmcplugin.setResolvedUrl(HANDLE_ID, True, listitem=listitem)
	else:
		Player().play(url, listitem)
