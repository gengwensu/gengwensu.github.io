# -*- coding: utf-8 -*-

'''*
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*'''

import re
import inspect
from commoncore import kodi
from commoncore import filelock

sqlite_replace = re.compile("^[\s\t\n]*replace[\s\t\n]*into[\s\t\n]*", re.IGNORECASE)

class DatabaseConnectionException(Exception):
	pass

class DatabaseSQLException(Exception):
	pass

class DatabaseLockException(Exception):
	pass

class DB_API_BASE(object):
	connector 	= None
	DBH			= None
	DBC			= None
	db_type		= None
	db_version 	= 1
	schema_file = ""
	_transaction = False
	
	@property
	def transaction(self):
		return self._transaction
	
	@property
	def conn(self):
		return None

	def begin_transaction(self):
		pass
	
	def end_transaction(self):
		pass

	def commit(self):
		kodi.debug("Commit Transaction")
		self.DBH.commit()
	
	def rollback(self):
		pass
	
	def prepare_sql(self, SQL):
		return SQL
	
	def prepare_data(self, data):
		return data
	
	def prepare_many(self, data):
		return self.prepare_data(data)
	
	def to_dict(self, conn, temp):
		results = []
		for t in temp:
			d = {col: [idx] for idx, col in enumerate(conn.column_names)}
			results.append(d)
		return results
	
	def query(self, SQL, data=None, to_dict=False):
		SQL = self.prepare_sql(SQL)
		conn = self.conn
		if data is None:
			conn.execute(SQL)
		else:
			conn.execute(SQL, self.prepare_data(data))
		results = conn.fetchall()
		if to_dict:
			return self.to_dict(conn, results)
		else:
			return results
	
	def query_assoc(self, SQL, data=None):
		return self.query(SQL, data, True)
	
	def execute(self, SQL, data=None):
		SQL = self.prepare_sql(SQL)
		conn = self.conn
		if data is None:
			conn.execute(SQL)
		else:
			conn.execute(SQL, self.prepare_data(data))
		try:
			return conn.lastrowid
		except:
			return None
	
	def insert(self, SQL, data):
		self.execute(SQL, data)
	
	def insert_many(self, SQL, data):
		SQL = self.prepare_sql(SQL)
		conn = self.conn
		conn.executemany(SQL, self.prepare_many(data))
	
	def run_script(self, sql_file, commit=True):
		self.begin_transaction()
		try:
			full_sql = kodi.vfs.read_file(sql_file)
			sql_stmts = full_sql.split(';\n')
			for SQL in sql_stmts:
				if SQL is not None and len(SQL.strip()) > 0:
					kodi.info(SQL)
					self.execute(SQL)
			self.execute('DELETE FROM version')
			self.execute('INSERT INTO version(db_version) VALUES(?)', [self.db_version])
			if commit: self.commit()
			return True
		except:
			self.rollback()
			return False
	
	def initialize(self):
		try:
			test = self.query("SELECT 1 FROM version WHERE db_version >= ?", [self.db_version])
			return False
		except:
			kodi.info("Do Init")
			schema_file = self.schema_file if self.schema_file else kodi.vfs.join(kodi.get_path(), 'resources/database/schema.%s.sql' % self.db_type)
			self.run_script(schema_file)
	
class SQLITE_API(DB_API_BASE):
	db_type = "sqlite"
	def __init__(self, dsn, lock_timeout=15):
		from sqlite3 import dbapi2 as connector
		self.connector = connector
		self.dsn = dsn
		self.db_version = dsn["version"] if "version" in dsn else 1
		self.schema_file = dsn["schema_file"] if "schema_file" in dsn else ""
		self.db_lock = filelock.FileLock(dsn['database'] + ".lock", timeout=lock_timeout)
		self.initialize()
	
	def database_lock(foo):
		def wrapper(self, *args, **kwargs):
			if self.transaction: return foo(self, *args, **kwargs)
			with self.db_lock:
				kodi.debug("Acquire lock %s by %s" % (self.dsn['database'], inspect.stack()[-1][1]))
				try:
					r = foo(self, *args, **kwargs)
				except DatabaseLockException as e:
					kodi.debug("SQLite Database Error: %s" % e)
				finally:
					kodi.debug("Release lock %s" % self.dsn['database'])
					self.db_lock.release()
			return r
		return wrapper
	
	def prepaire_sql(self, SQL):
		if sqlite_replace.search(SQL): SQL = 'INSERT OR ' + SQL
		return SQL
	
	@property
	@database_lock
	def conn(self):
		if self.transaction and self.DBC is not None: return self.DBC
		try:
			kodi.debug("Connecting to {}".format(self.dsn["database"]))
			if self.DBH is None:
				self.DBH = self.connector.connect(self.dsn['database'], check_same_thread=False)
			self.DBC = self.DBH.cursor()
			return self.DBC
		except DatabaseConnectionException as e:
			raise e
		return None
	
	def commit(self):
		self.DBH.commit()
		if self.transaction: 
			kodi.debug("Commit Transaction")
			self.end_transaction()
			
	@database_lock
	def begin_transaction(self):
		kodi.debug("Begin Transaction")
		self._transaction = True
		self.conn
		self.execute("BEGIN")
	
	def end_transaction(self):
		self.DBC = None
		self._transaction = False
	
	def rollback(self):
		self.DBH.rollback()
		self.end_transaction()
		kodi.debug("Rollback Transaction")
	
	def to_dict(self, conn, temp):
		results = []
		for t in temp:
			d = {col[0]: t[idx] for idx, col in enumerate(conn.description)}
			results.append(d)
		return results

class MYSQL_API(DB_API_BASE):
	db_type = "mysql"
	def __init__(self, dsn):
		import mysql.connector as connector
		self.connector = connector
		self.dsn = dsn
		if "version" in dsn:
			self.db_version = dsn["version"]
			del dsn["version"]
		if "schema_file" in dsn: 
			self.schema_file = dsn["schema_file"] 
			del dsn["schema_file"]
		self.initialize()
	
	@property
	def conn(self):
		if self.DBC is not None and self.DBH.in_transaction: return self.DBC
		try:
			kodi.debug("Connecting to {} on {}".format(self.dsn["database"], self.dsn["host"]))
			if self.DBH is None:
				self.DBH = self.connector.connect(**self.dsn)
				self.DBH.set_autocommit("OFF")
			return self.DBH.cursor()
		except DatabaseConnectionException as e:
			raise e
		return None
	
	def prepare_sql(self, SQL):
		SQL = SQL.replace('?', '%s')
		return SQL
	
	def prepare_data(self, data):
		_type = type(data)
		if _type is list:
			data = tuple(data)
		return data
	
	def prepare_many(self, temp):
		data = []
		for t in temp:
			data.append(self.prepare_data(t))
		return data
	
	def begin_transaction(self):
		kodi.debug("Begin Transaction")
		self.conn
		self.DBH.start_transaction()
		
	def rollback(self):
		kodi.debug("Rollback Transaction")
		self.DBH.rollback()