Refer to https://cywteow.github.io/ for installation instruction
